public class TeddyFaulkProfile {
  /* My Profile In Java */
  static String name = "Teddy Faulk";

  static String campus = "Pittsburgh";

  static String careerGoal = "Fullstack Developer";

  static int age = 22;

  static String introduction = "My name is Teddy! I am very excited to begin my internship and hopefully earn some back-end coding as a shared services engineer!";

  public static void main(final String[] args) {
    System.out.println(TeddyFaulkProfile.name);
    System.out.println(TeddyFaulkProfile.campus);
    System.out.println(TeddyFaulkProfile.careerGoal);
    System.out.println(TeddyFaulkProfile.age);
    System.out.println(TeddyFaulkProfile.introduction);
  }
}
